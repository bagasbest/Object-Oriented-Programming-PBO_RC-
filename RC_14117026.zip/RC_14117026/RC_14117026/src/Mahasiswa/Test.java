/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mahasiswa;

/**
 *
 * @author user
 */
public class Test {
       public static void main (String[] args){
              Mahasiswa mhs = new Mahasiswa(12345, "Budi Mikarti");
              System.out.println("NRP: "+mhs.getNRP());
              System.out.println("Nama: "+mhs.getNama());
       }
}
