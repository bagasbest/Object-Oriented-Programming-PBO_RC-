/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mahasiswa;

/**
 *
 * @author user
 */
public class Mahasiswa {
       public int nip;
       public String  nama;
       
       public Mahasiswa(int i, String n){
              nip = i;
              nama = n;
       }
       
       public int getNRP (){
           return nip;
       }
       
       public String getNama (){
              return nama;
       }
}
