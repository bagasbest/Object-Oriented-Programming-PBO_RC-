/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lingkaran;

/**
 *
 * @author user
 */
public class Lingkaran {
       public double jari;
       
       public void isijari(double i){
              jari = i;
       }
       
       public double getLuas (){
              return 3.14*jari*jari;  
       }
       
       public double getKeliling (){
              return 6.28*jari;
       }
       
       public void getHasil(){
              System.out.println("jadi luasnya "+getLuas()+ " sedangkan kelilingnya "+getKeliling());   
       }
}
